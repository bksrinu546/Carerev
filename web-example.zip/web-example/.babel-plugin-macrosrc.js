module.exports = {
  styledComponents: {
    displayName: process.env.NODE_ENV !== 'production',
  },
};
