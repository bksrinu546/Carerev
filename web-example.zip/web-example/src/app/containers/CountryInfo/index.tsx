import React, { useEffect, useState } from 'react';
import { PageWrapper } from 'app/components/PageWrapper';


import { request } from 'utils/request';
import axios from 'axios';
import { useParams } from 'react-router-dom';
export function CountryInfo() {
  debugger
  const countryId:any = useParams();
  const [countryInfo, setCountryInfo] = useState({
    id: null,
    name: null,
    currency_code:null,
  });
  const requestURL = `https://api.carerev.com/api/v1/countries/`;
  useEffect(() => {
    
    axios
      .get(requestURL + countryId.id)
      .then(response => {
        setCountryInfo(response.data);
      })
      .catch(error => {
        console.log(error);
      });
  });

  return (
    <PageWrapper>
      <h1>Country Info</h1>     
      
         <ul>       
              <div>{countryInfo.name}</div>
              <div>{ countryInfo.currency_code}</div>       
        </ul>        
    </PageWrapper>
  );


}
