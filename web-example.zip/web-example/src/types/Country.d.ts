export interface Country {
  id: string;
  name: string;
  currency_code:string;
}
